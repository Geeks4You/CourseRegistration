﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseRegistration
{
    /*  Program Name:   CourseRegistration
     *  Programmer:     Learning Team C
     *  Date:           11-14-2016
     *  Description:    This program will be a Windows Forms application. Design an interface that is professional 
     *  looking and intuitive to use for the novice end user.
     *  The Main menu should offer choices including, but not limited to:
        •	Adding students
        •	Adding faculty members
        •	Adding courses
        •	Registering students to course(s)
        •	Printing a registration report 
        •	Exiting Program
     *  No code is necessary behind each menu option at this time. If you would like, when the user selects a given 
     *  option, you can display a messagebox such as "Adding Courses menu option selected".
     *  
     */
    public partial class CourseRegistration : Form
    {
        /* This class represents the MDI Parent for the application. It provides the MenuBar from which all other
         * application forms are instantiated.
         */
        #region Constructors
        public CourseRegistration()
        {
            InitializeComponent();
        }
        #endregion Constructors

        #region Event handlers
        private void CourseRegistration_Load(object sender, EventArgs e)
        {   //Display the splash window when the application starts
            frmSplash fSplash = new frmSplash();
            fSplash.MdiParent = this;
            fSplash.Show();
        }
        private void facultyToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on Maintain->Faculty
            frmMaintainFaculty fMaintainFaculty = new frmMaintainFaculty();
            fMaintainFaculty.MdiParent = this;
            fMaintainFaculty.Show();
        }
        private void courseToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on Maintain->Course
            frmMaintainCourses fMaintainCourse = new frmMaintainCourses();
            fMaintainCourse.MdiParent = this;
            fMaintainCourse.Show();
        }
        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on Maintain->Registration
            frmRegistration fRegistration = new frmRegistration();
            fRegistration.MdiParent = this;
            fRegistration.Show();
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on Help->About
            frmAbout fAbout = new frmAbout();
            fAbout.ShowDialog();
        }
        private void fileExitToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on File->Exit
            this.Close();
        }
        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on Maintain->Students
            frmMaintainStudents fMaintainStudent = new frmMaintainStudents();
            fMaintainStudent.MdiParent = this;
            fMaintainStudent.Show();
        }
        private void helpHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {   //Uer clicked on Help->Help
            MessageBox.Show("No HELP yet.");
        }
        #endregion Event handlers
    }
}
