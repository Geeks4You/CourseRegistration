﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseRegistration
{
    public partial class frmSelectFaculty : Form
    {
        public frmSelectFaculty()
        {
            InitializeComponent();
        }

        private void frmSelectFaculty_Load(object sender, EventArgs e)
        {
            Globals.LoadFaculty(cboFaculty);
        }

        private void cboFaculty_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmdSelect.Enabled = (cboFaculty.SelectedIndex > -1);
        }
    }
}
