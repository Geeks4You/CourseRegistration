﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseRegistration
{
    /*  Program Name:   CourseRegistration
     *  Programmer:     Learning Team C
     *  Date:           11-14-2016
     *  Description:    Using Microsoft® Visual Studio®, develop the details of the first three 
     *  menu options using the program in Week Two and expanding upon it.
     *  Review the following for an example:
     *  Adding students - The following data should be collected from student users: 
     *      First name
     *      Last name
     *      Student ID number
     *      Address
     *      Phone
     *      E-mail
     *      Degree program
     *  Adding faculty members - The following data should be collected from faculty users: 
     *      First name
     *      Last name
     *      Faculty ID number
     *      Address
     *      Phone
     *      E-mail
     *      College program
     *  Adding courses  - The following data should be collected: 
     *      Course number
     *      Course description
     *      Start date
     *      End date
     *      Location
     *      Number of credits
     *      Faculty ID number
     * The program should store user inputs in flat files. Hint: Use a class (or classes) 
     * to create custom types. Include identifying information in the form of block 
     * comments at the top of each class in the project (team name, date, program description).
     * Include adequate comments throughout the program, utilize meaningful names for controls, 
     * variables, fields, and forms. Include white space for readability purposes in the code. 
     * Refer to the Programming Assignment grading form to view grading criteria
     *  
     */
    public partial class CourseRegistration : Form
    {
        /* This class represents the MDI Parent for the application. It provides the MenuBar from which all other
         * application forms are instantiated.
         */
        #region Constructors
        public CourseRegistration()
        {
            InitializeComponent();
        }
        #endregion Constructors

        #region Event handlers
        private void CourseRegistration_Load(object sender, EventArgs e)
        {   //Display the splash window when the application starts
            frmSplash fSplash = new frmSplash();
            fSplash.MdiParent = this;
            fSplash.Show();
        }
        private void facultyToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on Maintain->Faculty
            frmMaintainFaculty fMaintainFaculty = new frmMaintainFaculty();
            fMaintainFaculty.MdiParent = this;
            fMaintainFaculty.Show();
        }
        private void courseToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on Maintain->Course
            frmMaintainCourses fMaintainCourse = new frmMaintainCourses();
            fMaintainCourse.MdiParent = this;
            fMaintainCourse.Show();
        }
        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on Maintain->Registration
            MessageBox.Show("Feature not availabe until Week 4", "Feature not available", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on Help->About
            frmAbout fAbout = new frmAbout();
            fAbout.ShowDialog();
        }
        private void fileExitToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on File->Exit
            this.Close();
        }
        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on Maintain->Students
            frmMaintainStudents fMaintainStudent = new frmMaintainStudents();
            fMaintainStudent.MdiParent = this;
            fMaintainStudent.Show();
        }
        private void helpHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {   //User clicked on Help->Help
            MessageBox.Show("No HELP yet.");
        }
        #endregion Event handlers
    }
}
