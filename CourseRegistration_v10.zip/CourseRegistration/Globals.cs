﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseRegistration
{
    public static class Globals
    {
        #region Load Controls
        public static void LoadStates(ComboBox cboStates)
        {   //Loado the state abbreviations into the combo box
            cboStates.Items.Add("AL");
            cboStates.Items.Add("AK");
            cboStates.Items.Add("AS");
            cboStates.Items.Add("AZ");
            cboStates.Items.Add("AR");
            cboStates.Items.Add("CA");
            cboStates.Items.Add("CO");
            cboStates.Items.Add("CT");
            cboStates.Items.Add("DE");
            cboStates.Items.Add("DC");
            cboStates.Items.Add("FL");
            cboStates.Items.Add("GA");
            cboStates.Items.Add("GU");
            cboStates.Items.Add("HI");
            cboStates.Items.Add("ID");
            cboStates.Items.Add("IL");
            cboStates.Items.Add("IN");
            cboStates.Items.Add("IA");
            cboStates.Items.Add("KS");
            cboStates.Items.Add("KY");
            cboStates.Items.Add("LA");
            cboStates.Items.Add("ME");
            cboStates.Items.Add("MD");
            cboStates.Items.Add("MH");
            cboStates.Items.Add("MA");
            cboStates.Items.Add("MI");
            cboStates.Items.Add("FM");
            cboStates.Items.Add("MN");
            cboStates.Items.Add("MS");
            cboStates.Items.Add("MO");
            cboStates.Items.Add("MT");
            cboStates.Items.Add("NE");
            cboStates.Items.Add("NV");
            cboStates.Items.Add("NH");
            cboStates.Items.Add("NJ");
            cboStates.Items.Add("NM");
            cboStates.Items.Add("NY");
            cboStates.Items.Add("NC");
            cboStates.Items.Add("ND");
            cboStates.Items.Add("MP");
            cboStates.Items.Add("OH");
            cboStates.Items.Add("OK");
            cboStates.Items.Add("OR");
            cboStates.Items.Add("PW");
            cboStates.Items.Add("PA");
            cboStates.Items.Add("PR");
            cboStates.Items.Add("RI");
            cboStates.Items.Add("SC");
            cboStates.Items.Add("SD");
            cboStates.Items.Add("TN");
            cboStates.Items.Add("TX");
            cboStates.Items.Add("UT");
            cboStates.Items.Add("VT");
            cboStates.Items.Add("VA");
            cboStates.Items.Add("VI");
            cboStates.Items.Add("WA");
            cboStates.Items.Add("WV");
            cboStates.Items.Add("WI");
            cboStates.Items.Add("WY");
        }
        public static void LoadStudents(ComboBox cboStudents)
        {
            String StudentLine;
            System.IO.StreamReader StudentFile = new System.IO.StreamReader("Student.csv");
            while ((StudentLine = StudentFile.ReadLine()) != null)
            {
                Student student = new Student(StudentLine);
                if (student != null)
                {
                    cboStudents.Items.Add(student);
                }
            }
            StudentFile.Close();
        }
        public static void LoadFaculty(ComboBox cboFaculty)
        {
            String FacultyLine;
            System.IO.StreamReader FacultyFile = new System.IO.StreamReader("Faculty.csv");
            while ((FacultyLine = FacultyFile.ReadLine()) != null)
            {
                Faculty faculty = new Faculty(FacultyLine);
                if (faculty != null)
                {
                    cboFaculty.Items.Add(faculty);
                }
            }
            FacultyFile.Close();
        }
        public static void LoadCourses(ComboBox cboCourses)
        {
            String CourseLine;
            System.IO.StreamReader CourseFile = new System.IO.StreamReader("Course.csv");
            while ((CourseLine = CourseFile.ReadLine()) != null)
            {
                Course course = new Course(CourseLine);
                if (course != null)
                {
                    cboCourses.Items.Add(course);
                }
            }
            CourseFile.Close();
        }
        #endregion Load Controls

        #region Singleton Selects
        public static Faculty GetFaculty(Int16 FacultyID)
        {
            Faculty faculty = null;

            String FacultyLine;
            System.IO.StreamReader FacultyFile = new System.IO.StreamReader("Faculty.csv");
            while ((FacultyLine = FacultyFile.ReadLine()) != null)
            {
                String[] szColumn = FacultyLine.Split(',');
                if (szColumn.Length == 11)
                {
                    if (Convert.ToInt16(szColumn[0]).Equals(FacultyID))
                    {
                        faculty = new Faculty(FacultyLine);
                        /*
                        faculty.ID = Convert.ToInt16(szColumn[0]);
                        faculty.FirstName = szColumn[1];
                        faculty.LastName = szColumn[2];
                        faculty.Program = szColumn[3];
                        faculty.AddressLine1 = szColumn[4];
                        faculty.AddressLine2 = szColumn[5];
                        faculty.City = szColumn[6];
                        faculty.State = szColumn[7];
                        faculty.Zip = szColumn[8];
                        faculty.Phone = szColumn[9];
                        faculty.Email = szColumn[10];
                        */
                    }
                }
            }
            FacultyFile.Close();

            return faculty;
        }
        public static ArrayList GetRelatedFacultyForCourse(Int16 CourseID)
        {
            ArrayList alFaculty = new ArrayList();
            String CourseFacultyLine;
            System.IO.StreamReader CourseFacultyFile = new System.IO.StreamReader("CourseFaculty.csv");
            while ((CourseFacultyLine = CourseFacultyFile.ReadLine()) != null)
            {
                String[] szColumn = CourseFacultyLine.Split(',');
                if (szColumn.Length == 2)
                {
                    if (Convert.ToInt16(szColumn[0]).Equals(CourseID))
                    {
                        Faculty faculty = GetFaculty(Convert.ToInt16(szColumn[1]));
                        if (faculty != null)
                        {
                            alFaculty.Add(faculty);
                        }
                    }
                }
            }
            CourseFacultyFile.Close();

            return alFaculty;
        }
        public static Course GetCourse(Int16 CourseID)
        {
            Course course = null;

            String CourseLine;
            System.IO.StreamReader CourseFile = new System.IO.StreamReader("Course.csv");
            while ((CourseLine = CourseFile.ReadLine()) != null)
            {
                course = new Course(CourseLine);
                if (course.ID.Equals(CourseID))
                {
                    break;
                }
            }
            CourseFile.Close();

            return course;
        }
        public static Student GetStudent(Int16 StudentID)
        {
            Student student = null;

            String StudentLine;
            System.IO.StreamReader StudentFile = new System.IO.StreamReader("Student.csv");
            while ((StudentLine = StudentFile.ReadLine()) != null)
            {
                student = new Student(StudentLine);
                if (student.ID.Equals(StudentID))
                {
                    break;
                }
            }
            StudentFile.Close();

            return student;
        }
        #endregion Singleton selects

        #region Deletes
        public static void DeleteRegistration(Int16 StudentID, Int16 CourseID)
        {
            Course course = Globals.GetCourse(CourseID);
            if (course == null)
            {
                throw new Exception("ERROR: Invalid Course ID (" + CourseID.ToString() + ")");
                //return;
            }
            Student student = Globals.GetStudent(StudentID);
            if (student == null)
            {
                throw new Exception("ERROR: Invalid Student ID (" + StudentID.ToString() + ")");
                //return;
            }

            if (MessageBox.Show("Are you sure you want to UnRegister course number " + course.CourseNumber + " from student named " + student.FirstName + " " + student.LastName + " ?", "Confirm UnRegister", MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(DialogResult.No))
            {
                return;
            }

            ArrayList alOutput = new ArrayList();

            String RegistrationLine;
            System.IO.StreamReader RegistrationFile = new System.IO.StreamReader("Registration.csv");
            while ((RegistrationLine = RegistrationFile.ReadLine()) != null)
            {
                Registration registration = new Registration(RegistrationLine);
                if ((registration.StudentID.Equals(StudentID)) && (registration.CourseID.Equals(CourseID)))
                {
                }
                else
                {
                    alOutput.Add(RegistrationLine);
                }
            }
            RegistrationFile.Close();

            using (System.IO.StreamWriter file = new System.IO.StreamWriter("Registration.csv", false))
            {
                foreach (String s in alOutput)
                {
                    file.WriteLine(s);
                }
                file.Close();
            }
        }
        public static void DeleteCourseFaculty(Int16 CourseID, Int16 FacultyID)
        {
            Course course = Globals.GetCourse(CourseID);
            if (course == null)
            {
                throw new Exception("ERROR: Invalid Course ID (" + CourseID.ToString() + ")");
                //return;
            }
            Faculty faculty = Globals.GetFaculty(FacultyID);
            if (faculty == null)
            {
                throw new Exception("ERROR: Invalid Student ID (" + FacultyID.ToString() + ")");
                //return;
            }

            if (MessageBox.Show("Are you sure you want to remove the faculty member named " + faculty.FirstName + " " + faculty.LastName + " as an instructor of course number " + course.CourseNumber + " ?", "Confirm Remove Instructor", MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(DialogResult.No))
            {
                return;
            }

            ArrayList alOutput = new ArrayList();

            String CourseFacultyLine;
            System.IO.StreamReader CourseFacultyFile = new System.IO.StreamReader("CourseFaculty.csv");
            while ((CourseFacultyLine = CourseFacultyFile.ReadLine()) != null)
            {
                CourseFaculty coursefaculty = new CourseFaculty(CourseFacultyLine);
                if (coursefaculty != null)
                {
                    if ((coursefaculty.FacultyID.Equals(FacultyID)) && (coursefaculty.CourseID.Equals(CourseID)))
                    {
                    }
                    else
                    {
                        alOutput.Add(CourseFacultyLine);
                    }
                }
            }
            CourseFacultyFile.Close();

            using (System.IO.StreamWriter file = new System.IO.StreamWriter("CourseFaculty.csv", false))
            {
                foreach (String s in alOutput)
                {
                    file.WriteLine(s);
                }
                file.Close();
            }
        }
        #endregion Deletes

        #region Referential Integrity checks
        public static bool StudentIsRegistered(Int16 StudentID)
        {
            bool bResult = false;

            String RegistrationLine;
            System.IO.StreamReader RegistrationFile = new System.IO.StreamReader("Registration.csv");
            while ((RegistrationLine = RegistrationFile.ReadLine()) != null)
            {
                Registration registration = new Registration(RegistrationLine);
                if (registration.StudentID.Equals(StudentID)) 
                {
                    bResult = true;
                    break;
                }
            }
            RegistrationFile.Close();

            return bResult;
        }
        public static bool FacultyIsRegistered(Int16 FacultyID)
        {
            bool bResult = false;

            String RegistrationLine;
            System.IO.StreamReader RegistrationFile = new System.IO.StreamReader("Registration.csv");
            while ((RegistrationLine = RegistrationFile.ReadLine()) != null)
            {
                Registration registration = new Registration(RegistrationLine);
                if (FacultyTeachesCourse(registration.CourseID, FacultyID))
                {
                    bResult = true;
                    break;
                }
            }
            RegistrationFile.Close();

            return bResult;
        }
        public static bool FacultyTeachesCourse(Int16 CourseID, Int16 FacultyID)
        {
            bool bResult = false;

            String CourseFacultyLine;
            System.IO.StreamReader CourseFacultyFile = new System.IO.StreamReader("CourseFaculty.csv");
            while ((CourseFacultyLine = CourseFacultyFile.ReadLine()) != null)
            {
                CourseFaculty coursefaculty = new CourseFaculty(CourseFacultyLine);
                if ((coursefaculty.CourseID.Equals(CourseID)) && (coursefaculty.FacultyID.Equals(FacultyID)))
                {
                    bResult = true;
                    break;
                }
            }
            CourseFacultyFile.Close();

            return bResult;
        }
        public static bool CourseIsScheduled(Int16 CourseID)
        {
            bool bResult = false;

            String RegistrationLine;
            System.IO.StreamReader RegistrationFile = new System.IO.StreamReader("Registration.csv");
            while ((RegistrationLine = RegistrationFile.ReadLine()) != null)
            {
                Registration registration = new Registration(RegistrationLine);
                if (registration.CourseID.Equals(CourseID))
                {
                    bResult = true;
                    break;
                }
            }
            RegistrationFile.Close();

            return bResult;
        }
        #endregion Referential Integrity checks
    }
}
